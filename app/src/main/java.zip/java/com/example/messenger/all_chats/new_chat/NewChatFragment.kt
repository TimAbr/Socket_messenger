package com.example.messenger.all_chats.new_chat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.registerReceiver
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.findNavController
import com.example.messenger.databinding.FragmentNewChatBinding
import com.example.messenger.network.ClientService
import com.example.messenger.network.ClientService.Companion.EXTRA_EXISTS
import com.example.messenger.network.ConnectionManager


class NewChatFragment : Fragment() {

    private val viewModel: NewChatViewModel by viewModels()

    var _binding: FragmentNewChatBinding? = null
    val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNewChatBinding.inflate(inflater, container, false)

        viewModel.isRequesting.observe(viewLifecycleOwner, {
            value->
            binding.progressBar.visibility = if (value) ProgressBar.VISIBLE else ProgressBar.INVISIBLE
        })

        binding.viewModel = viewModel

        binding.button.setOnClickListener{
            if (!viewModel.isRequesting.value!!){
                viewModel.isRequesting.value = true

                val connectionManager = ConnectionManager(requireContext())
                connectionManager.checkUserExistence(viewModel.chatName)
            }
        }


        val filter = IntentFilter()
        filter.addAction(ClientService.ACTION_USER_EXISTS)

        val updateUIReciver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {

                viewModel.isRequesting.value = false

                if(!intent.getBooleanExtra(ClientService.EXTRA_EXISTS, false)) {
                    Toast.makeText(
                        context,
                        "No such user",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    val action = NewChatFragmentDirections.actionNewChatFragmentToChatFragment(viewModel.chatName)
                    requireView().findNavController().navigate(action)
                }
            }
        }
        registerReceiver(requireContext(),updateUIReciver, filter, ContextCompat.RECEIVER_EXPORTED)


        return binding.root
    }

}