package com.example.messenger.settings.server

import androidx.lifecycle.ViewModel

class ServerSettingsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}