package com.example.messenger.all_chats

import androidx.lifecycle.ViewModel

class ChatsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}