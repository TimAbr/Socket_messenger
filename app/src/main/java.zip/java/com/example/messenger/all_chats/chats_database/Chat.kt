package com.example.messenger.all_chats.chats_database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chats_table")
data class Chat(
    @PrimaryKey(autoGenerate = true)
    var id: Long = 0,

    @ColumnInfo(name = "chat_id")
    var chatId: Long = 0,

    @ColumnInfo(name = "chat_name")
    var chatName: String = "",
)