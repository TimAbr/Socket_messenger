package com.example.messenger.all_chats.chats_database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Chat::class], version = 1, exportSchema = false)
abstract class ChatsDatabase: RoomDatabase() {
    abstract val chatDao: ChatsDao

    companion object{
        @Volatile
        private var INSTANCE: ChatsDatabase? = null

        fun getInstance(context: Context): ChatsDatabase {
            synchronized(this){
                var instance = INSTANCE
                if (instance==null){
                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        ChatsDatabase::class.java,
                        "chats_database"
                    ).build()
                    INSTANCE=instance
                }
                return  instance
            }

        }
    }

}