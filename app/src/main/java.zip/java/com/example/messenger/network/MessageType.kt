package com.example.messenger.network

enum class MessageType{
    COMMAND_MESSAGE,
    DATA_MESSAGE
}
